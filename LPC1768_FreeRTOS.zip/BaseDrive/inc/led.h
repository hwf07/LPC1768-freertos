#ifndef _LED_H_
#define _LED_H_
//X��ֵ����0,LED��X��ֵ����1��LED����
//Chip_GPIO_SetPinOutHigh(LPC_GPIO,2,0)  //����P2.0����ߵ�ƽ
//Chip_GPIO_SetPinOutLow(LPC_GPIO,2,0)  //����P2.0����͵�ƽ
#define LED_HRERT_ON(x) ((x) ? (Chip_GPIO_SetPinOutHigh(LPC_GPIO,0,7)) :  (Chip_GPIO_SetPinOutLow(LPC_GPIO,0,7)));
#define LED5_ON(x) ((x) ? (Chip_GPIO_SetPinOutHigh(LPC_GPIO,2,1)) : (Chip_GPIO_SetPinOutLow(LPC_GPIO,2,1)));
#define LED6_ON(x) ((x) ? (Chip_GPIO_SetPinOutHigh(LPC_GPIO,2,2)) : (Chip_GPIO_SetPinOutLow(LPC_GPIO,2,2)));
#define LED7_ON(x) ((x) ? (Chip_GPIO_SetPinOutHigh(LPC_GPIO,2,3)) : (Chip_GPIO_SetPinOutLow(LPC_GPIO,2,3)));
#define LED8_ON(x) ((x) ? (Chip_GPIO_SetPinOutHigh(LPC_GPIO,2,4)) : (Chip_GPIO_SetPinOutLow(LPC_GPIO,2,4)));
#define LED9_ON(x) ((x) ? (Chip_GPIO_SetPinOutHigh(LPC_GPIO,2,5)) : (Chip_GPIO_SetPinOutLow(LPC_GPIO,2,5)));
#define LED10_ON(x)((x) ? (Chip_GPIO_SetPinOutHigh(LPC_GPIO,2,6)) : (Chip_GPIO_SetPinOutLow(LPC_GPIO,2,6)));
#define LED11_ON(x)((x) ? (Chip_GPIO_SetPinOutHigh(LPC_GPIO,2,7)) : (Chip_GPIO_SetPinOutLow(LPC_GPIO,2,7)));
void LED_Config(void);

#endif 

