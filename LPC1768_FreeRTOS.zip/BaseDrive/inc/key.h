#ifndef _KEY_H_
#define _KEY_H_
void KEY_Config(void);
int Key_Scan(void);

#endif

